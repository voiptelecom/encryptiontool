#!/bin/bash
/usr/bin/md5sum /etc/asterisk/sip_magnus_user.conf > /home/crtool/nuevo
DIFERENTES="$(cmp --silent /home/crtool/actual /home/crtool/nuevo && echo '0' || echo '1')"

if [ $DIFERENTES -gt "0" ]; then
	echo "ejecuta $DIFERENTES"
	cp /etc/asterisk/sip_magnus_user.conf /home/crtool/textobase
	sed '/./,$!d' /home/crtool/textobase > /home/crtool/textoLimpiado
	sed '/allowtransfer=/a\INSERTATLSAQUINOUSESESTESTRINGENOTRACOSA' /home/crtool/textoLimpiado > /home/crtool/textoPREPARADO
	sed '/INSERTATLSAQUINOUSESESTESTRINGENOTRACOSA/r /home/crtool/adicional' /home/crtool/textoPREPARADO > /home/crtool/textoPREPROCESADO	
	sed '/INSERTATLSAQUINOUSESESTESTRINGENOTRACOSA/d' /home/crtool/textoPREPROCESADO > /home/crtool/textoFINAL
	cat /home/crtool/textoFINAL > /etc/asterisk/sip_ajtel_usertls.conf
	/usr/sbin/asterisk -rx 'sip reload' && cat /home/crtool/nuevo > /home/crtool/actual
else
	echo "Sin Cambios $DIFERENTES"
fi

